public class q4 {
    public static void main(String[] args) {
        for (int i = 1; i <= 20; i++) {
            // Rule 2: Stop the loop if number becomes greater than 15
            if (i > 15) {
                break;
            }

            // Rule 1: Skip multiples of 3
            if (i % 3 == 0) {
                continue;
            }

            System.out.print(i + " ");
        }
    }
}
