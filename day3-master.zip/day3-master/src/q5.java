import java.util.Scanner;

public class q5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] numbers = new int[5];

        System.out.println("Enter 5 numbers:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.print("Element " + (i + 1) + ": ");
            numbers[i] = scanner.nextInt();
        }

        // Core Logic: Finding Sum and Max
        int sum = 0;
        int max = numbers[0]; // Assume the first element is the largest initially

        for (int num : numbers) {
            sum += num;       // Add current number to sum
            if (num > max) {
                max = num;    // Update max if current number is larger
            }
        }

        // Displaying results
        System.out.println("\nResults:");
        System.out.println("Sum of elements: " + sum);
        System.out.println("Maximum element: " + max);

        scanner.close();
    }
}

